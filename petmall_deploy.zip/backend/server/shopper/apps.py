from django.apps import AppConfig


class ShopperConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shopper'
    verbose_name = '订单管理'
