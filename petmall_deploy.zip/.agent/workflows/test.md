---
description: Enforce project code structure: All test scripts, data insertion scripts, and SQL scripts must be placed in the root-level test folder, separate from business code.
---

# Project Code Structure Skill (Auto-Enforced)
## Core Rule
All test-related code and data scripts **MUST** be placed in the `test` folder at the project root (same level as `backend` and `frontend`), strictly separated from business code.

## Detailed Requirements
1.  **Test Scripts**: All unit tests, API tests, integration tests, and any other test code must be stored in the `test` folder.
2.  **Data Scripts**: All data insertion scripts, initialization scripts, data generation scripts, and SQL scripts must be stored in the `test` folder.
3.  **Folder Location**: The `test` folder must be created at the project root, alongside `backend` and `frontend`.
4.  **Auto-Placement**: When generating any test or data-related code, automatically place it in the `test` folder without manual path specification.
5.  **Strict Separation**: Never place test code in business directories (e.g., `backend`, `frontend`). Business code and test code must be strictly isolated.