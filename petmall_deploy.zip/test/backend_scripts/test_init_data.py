import os
import django
import random
from decimal import Decimal
import datetime
# 数据插入测试脚本1

# 必须在最前面配置Django执行环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from accounts.models import User, SysRole
from commodity.models import Category, Product, Inventory

def create_users():
    print("🚀 [1/3] 正在创建初始角色与测试用户...")
    # 1. 创建角色
    admin_role, _ = SysRole.objects.get_or_create(role_code='ADMIN', defaults={'role_name': '超级管理员', 'description': '拥有最高权限'})
    user_role, _ = SysRole.objects.get_or_create(role_code='USER', defaults={'role_name': '普通买家', 'description': '前台购物用户'})

    # 2. 创建用户
    users_data = [
        {'username': 'test1', 'password': 'password123', 'realName': '张阿猫', 'phone': '13800000001', 'role': user_role},
        {'username': 'test2', 'password': 'password123', 'realName': '李傻狗', 'phone': '13800000002', 'role': user_role},
        {'username': 'test3', 'password': 'password123', 'realName': '王金鱼', 'phone': '13800000003', 'role': user_role},
    ]

    for u_data in users_data:
        if not User.objects.filter(username=u_data['username']).exists():
            user = User.objects.create_user(
                username=u_data['username'],
                password=u_data['password'],
                real_name=u_data['realName'],
                phone=u_data['phone'],
                role=u_data['role']
            )
            print(f"✅ 创建测试用户: {user.username}")
        else:
            print(f"⚠️ 用户已存在: {u_data['username']}")


def create_products():
    print("\n🚀 [2/3] 正在生成宠物分类与商品字典档案...")
    
    # 1. 生成大分类
    categories = [
        {"name": "汪喵主粮", "sort": 1},
        {"name": "零食罐头", "sort": 2},
        {"name": "日常消耗", "sort": 3},
        {"name": "逗趣玩具", "sort": 4},
        {"name": "出行牵引", "sort": 5},
    ]
    
    cat_objs = {}
    for cat in categories:
        obj, _ = Category.objects.get_or_create(name=cat['name'], level=1, defaults={'sort_order': cat['sort']})
        cat_objs[cat['name']] = obj
        print(f"✅ 创建分类: {obj.name}")

    # 2. 生成具体商品
    # 图片均使用 Unsplash 宠物主题优质图片
    products_data = [
        # 主粮类
        {"cat": "汪喵主粮", "name": "全价无谷冻干鲜肉猫粮 2KG", "img": "https://images.unsplash.com/photo-1548680695-9cd7cce9eab0?q=80&w=600", "price": 149.00, "old": 189.00, "desc": "高蛋白低肠胃负担，加入8%冻干，猫咪爱不释口。"},
        {"cat": "汪喵主粮", "name": "金毛拉布拉多成犬天然狗粮 10KG", "img": "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?q=80&w=600", "price": 288.50, "old": 350.00, "desc": "深海鱼油添加，强健骨骼，使毛发亮丽顺滑。"},
        {"cat": "汪喵主粮", "name": "幼猫断奶期专研营养奶糕", "img": "https://images.unsplash.com/photo-1573865526739-10659fec78a5?q=80&w=600", "price": 89.00, "old": 110.00, "desc": "好消化易吸收，帮助幼猫平稳度过断奶期。"},
        {"cat": "汪喵主粮", "name": "中小型犬通用烘焙粮 1.5KG", "img": "https://images.unsplash.com/photo-1589952283406-b53a7d1347e8?q=80&w=600", "price": 128.00, "old": 149.00, "desc": "低温慢烘，锁住营养，不添加任何诱食剂。"},
        {"cat": "汪喵主粮", "name": "老年犬关节保护专用主粮 5KG", "img": "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?q=80&w=600", "price": 220.00, "old": 250.00, "desc": "富含软骨素，专门针对老年宠物骨骼退化痛点。"},

        # 零食类
        {"cat": "零食罐头", "name": "泰国进口金枪鱼虾仁猫罐头 85g*6罐", "img": "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?q=80&w=600", "price": 59.90, "old": 79.90, "desc": "大块鲜肉，真材实料，补充日常水分。"},
        {"cat": "零食罐头", "name": "狗狗耐咬磨牙洁齿骨磨牙棒 10包", "img": "https://images.unsplash.com/photo-1537151608804-ea43c224f6fc?q=80&w=600", "price": 35.00, "old": 49.00, "desc": "洁齿除臭，解闷耐咬，减少拆家风险。"},
        {"cat": "零食罐头", "name": "纯自然原切冻干鸭肉冻干 100g", "img": "https://images.unsplash.com/photo-1623387641168-d9803ddd3f35?q=80&w=600", "price": 45.00, "old": 60.00, "desc": "清火去泪痕，复水后还原鲜肉口感。"},
        {"cat": "零食罐头", "name": "深海鱼油宠物爆毛丹 60粒", "img": "https://images.unsplash.com/photo-1524511751214-b0a384dc9c28?q=80&w=600", "price": 88.00, "old": 128.00, "desc": "富含 Omega-3，告别毛发干枯。"},
        {"cat": "零食罐头", "name": "补充营养羊奶粉 400g", "img": "https://images.unsplash.com/photo-1543852786-1cf6624b9987?q=80&w=600", "price": 68.00, "old": 88.00, "desc": "近母乳配方，幼宠、老宠、孕宠皆宜。"},

        # 日常消耗
        {"cat": "日常消耗", "name": "豆腐+膨润土混合猫砂 2.5KG*4包", "img": "https://images.unsplash.com/photo-1513360371669-4adf3dd7dff8?q=80&w=600", "price": 69.90, "old": 89.90, "desc": "除臭力强，结团快，可直接冲马桶。"},
        {"cat": "日常消耗", "name": "狗屎袋拾便袋环保降解 20卷", "img": "https://images.unsplash.com/photo-1552053831-71594a27632d?q=80&w=600", "price": 19.90, "old": 29.90, "desc": "厚实不脏手，环保材料自然降解。"},
        {"cat": "日常消耗", "name": "宠物专用干洗泡沫/沐浴露 500ml", "img": "https://images.unsplash.com/photo-1517849845537-4d257902454a?q=80&w=600", "price": 49.00, "old": 65.00, "desc": "温和不刺眼，植物提取留香持久。"},
        {"cat": "日常消耗", "name": "超强吸水除臭宠物尿垫 50张", "img": "https://images.unsplash.com/photo-1587559070757-f72a388edbba?q=80&w=600", "price": 28.50, "old": 40.00, "desc": "底层防漏设计，强力锁水锁味。"},
        {"cat": "日常消耗", "name": "全封闭式防带砂宽大猫砂盆", "img": "https://images.unsplash.com/photo-1615266895738-11f1371cd7e5?q=80&w=600", "price": 128.00, "old": 168.00, "desc": "给毛孩子私密空间，告别满地落砂。"},

        # 玩具类
        {"cat": "逗趣玩具", "name": "仙女棒羽毛铃铛逗猫棒", "img": "https://images.unsplash.com/photo-1629555239556-9b889312b918?q=80&w=600", "price": 12.80, "old": 18.00, "desc": "柔软羽毛加清脆铃铛，激发猫咪狩猎本能。"},
        {"cat": "逗趣玩具", "name": "抗抑郁发声尖叫鸡磨牙狗玩具", "img": "https://images.unsplash.com/photo-1624630571343-2cc563ac6741?q=80&w=600", "price": 15.00, "old": 25.00, "desc": "呆萌外表，魔性声调，狗狗的解闷好伙伴。"},
        {"cat": "逗趣玩具", "name": "自嗨不倒翁漏食球", "img": "https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?q=80&w=600", "price": 38.00, "old": 55.00, "desc": "边玩边吃，防止宠物进食过快。"},
        {"cat": "逗趣玩具", "name": "瓦楞纸猫抓板大号猫窝", "img": "https://images.unsplash.com/photo-1543852786-1cf6624b9987?q=80&w=600", "price": 25.90, "old": 39.90, "desc": "高密度加厚瓦楞纸，耐抓不掉屑。"},
        {"cat": "逗趣玩具", "name": "户外飞盘训练套装", "img": "https://images.unsplash.com/photo-1534361960057-19889db9621e?q=80&w=600", "price": 22.00, "old": 35.00, "desc": "软胶材质不伤狗嘴，增进主宠感情。"},

        # 出行/穿搭
        {"cat": "出行牵引", "name": "防爆冲一键锁止伸缩牵引绳 5米", "img": "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?q=80&w=600", "price": 58.00, "old": 88.00, "desc": "高强度尼龙带，自由伸缩，夜间反光。"},
        {"cat": "出行牵引", "name": "太空舱宠物双肩外出包", "img": "https://images.unsplash.com/photo-1596704017254-9b121068fb21?q=80&w=600", "price": 128.00, "old": 188.00, "desc": "大面积透气孔，给主子一览无遗的安全性。"},
        {"cat": "出行牵引", "name": "工字型防挣脱猫咪专用胸背带", "img": "https://images.unsplash.com/photo-1513245543132-31f507417b26?q=80&w=600", "price": 35.00, "old": 48.00, "desc": "贴合猫咪骨骼设计，有效防挣脱。"},
        {"cat": "出行牵引", "name": "超萌狗狗防寒保暖冬装外套", "img": "https://images.unsplash.com/photo-1583336663277-620dc1996580?q=80&w=600", "price": 68.00, "old": 98.00, "desc": "羊羔绒内胆，多种尺码适配各种体型。"},
        {"cat": "出行牵引", "name": "车载便携宠物安全座椅垫", "img": "https://images.unsplash.com/photo-1534361960057-19889db9621e?q=80&w=600", "price": 99.00, "old": 150.00, "desc": "防水防抓，自驾游带狗必备神器。"},
    ]

    create_count = 0
    for pd in products_data:
        # 判断商品是否已存在
        if not Product.objects.filter(name=pd['name']).exists():
            product = Product.objects.create(
                category=cat_objs[pd['cat']],
                name=pd['name'],
                main_image=pd['img'],
                description=pd['desc'],
                price=Decimal(str(pd['price'])),
                old_price=Decimal(str(pd['old'])),
                sales=random.randint(50, 2000),      # 随机销量
            )
            # 生成绑定的库存记录
            Inventory.objects.create(
                product=product,
                current_quantity=random.randint(10, 500)
            )
            create_count += 1
    
    if create_count > 0:
        print(f"✅ 成功生成 {create_count} 件商品与其独立的库存数据！")
    else:
        print("⚠️ 检测到商品数据已存在，不再重复生成。")

if __name__ == '__main__':
    print("-----------------------------------")
    print("   宠物商城数据库 Mock 数据初始化器")
    print("-----------------------------------")
    create_users()
    create_products()
    print("-----------------------------------")
    print("🎉 Initialization Completed! 所有测试数据已落库。")
