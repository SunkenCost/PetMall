import os
import django

# 设置环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from accounts.models import User

def promote():
    username = 'test1'
    u = User.objects.filter(username=username).first()
    if u:
        u.is_staff = True
        u.is_superuser = False
        u.save()
        print(f"User '{username}' is now a Merchant Admin (Staff=True, Superuser=False)")
    else:
        print(f"User '{username}' not found. Please register first.")

if __name__ == "__main__":
    promote()
