import os
import django
import requests
import sys

# 获取项目根目录，确保脚本可以访问 backend/server
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BACKEND_DIR = os.path.join(BASE_DIR, 'backend', 'server')
sys.path.append(BACKEND_DIR)

# 设置 Django 环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from commodity.models import Product

def localize_product_images():
    """
    将所有商品的外部链接图片下载到本地 media/imgs 目录，并更新数据库引用。
    """
    print("🚀 开始扫描并下载商品主图至本地存储...")
    
    # 路径解析：统一存放在 backend/server/media/imgs
    media_root = os.path.join(BACKEND_DIR, 'media', 'imgs')
    if not os.path.exists(media_root):
        os.makedirs(media_root)
        print(f"✅ 已创建目录: {media_root}")

    products = Product.objects.all()
    success_count = 0
    fail_count = 0
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    for p in products:
        # FileField 访问时需要转字符串
        image_val = str(p.main_image)
        
        if image_val and image_val.startswith('http'):
            print(f"📦 正在处理 [{p.id}] {p.name}...")
            url = image_val
            ext = '.jpg'
            if '.png' in url.lower():
                ext = '.png'
            
            file_name = f"pd_{p.id}{ext}"
            file_path = os.path.join(media_root, file_name)
            
            try:
                response = requests.get(url, headers=headers, timeout=10)
                if response.status_code == 200:
                    with open(file_path, 'wb') as f:
                        f.write(response.content)
                    
                    # 更新数据库为相对路径（Django 会自动加上 MEDIA_URL 前缀）
                    p.main_image = f"imgs/{file_name}"
                    p.save()
                    success_count += 1
                    print(f"  ✅ [完成] -> {p.main_image}")
                else:
                    print(f"  ❌ [失败] HTTP {response.status_code}")
                    fail_count += 1
            except Exception as e:
                print(f"  ❌ [错误] {e}")
                fail_count += 1
        else:
            print(f"➖ [跳过] [{p.id}] {p.name} (已本地化或路径不合规)")

    print(f"\n🎉 整理完成！")
    print(f"📊 成功本地化: {success_count} 张")
    print(f"⚠️ 下载失败: {fail_count} 张")

if __name__ == '__main__':
    localize_product_images()
