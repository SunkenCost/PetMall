"""
创建系统管理员账号（is_superuser=True）
用法：在 backend/server 目录下运行 python create_superuser.py
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from accounts.models import User, SysRole

# ========== 在这里修改你想要的账号密码 ==========
SUPERUSER_USERNAME = 'superadmin'
SUPERUSER_PASSWORD = 'admin123456'
SUPERUSER_EMAIL    = ''
SUPERUSER_REALNAME = '系统管理员'
# ==================================================

def main():
    if User.objects.filter(username=SUPERUSER_USERNAME).exists():
        u = User.objects.get(username=SUPERUSER_USERNAME)
        u.is_superuser = True
        u.is_staff = True
        u.is_active = True
        u.set_password(SUPERUSER_PASSWORD)
        u.save()
        print(f"账号「{SUPERUSER_USERNAME}」已存在，已更新为超级管理员并重置密码")
    else:
        # 确保有 ADMIN 角色
        role, _ = SysRole.objects.get_or_create(
            role_code='SUPERADMIN',
            defaults={'role_name': '系统管理员', 'description': '拥有最高权限的系统管理员'}
        )
        u = User.objects.create_superuser(
            username=SUPERUSER_USERNAME,
            password=SUPERUSER_PASSWORD,
            email=SUPERUSER_EMAIL,
            real_name=SUPERUSER_REALNAME,
            role=role,
        )
        print(f"创建成功！")

    print()
    print(f"  账号：{SUPERUSER_USERNAME}")
    print(f"  密码：{SUPERUSER_PASSWORD}")
    print(f"  权限：is_superuser=True  is_staff=True")
    print()
    print("成功")

if __name__ == '__main__':
    main()
