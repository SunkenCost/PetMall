import os
import django
import sys
# 邮件测试脚本1

# 设置 Django 环境
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from django.core.mail import send_mail
from django.conf import settings

def test_send():
    print(f"正在尝试使用 {settings.EMAIL_HOST}:{settings.EMAIL_PORT} 发送邮件...")
    print(f"发件人: {settings.EMAIL_HOST_USER}")
    
    try:
        send_mail(
            subject='【宠爱之家 PetMall】这是一封自动测试邮件',
            message='如果您看到这封邮件，说明您的 Django 邮件服务配置已成功！\n当前测试端口：' + str(settings.EMAIL_PORT),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=['xiexie10@foxmail.com'],
            fail_silently=False,
        )
        print("\n✅ 发送成功！请检查 xiexie10@foxmail.com 的收件箱（或垃圾箱）。")
    except Exception as e:
        print("\n❌ 发送失败！错误详情如下：")
        print("-" * 30)
        print(e)
        print("-" * 30)
        print("\n💡 调试建议：")
        if "TimeoutError" in str(e) or "ConnectionRefusedError" in str(e):
            print("  原因：网络超时。可能是您的服务器/电脑屏蔽了该端口的出站连接。")
        elif "Authentication failed" in str(e):
            print("  原因：认证失败。请检查 EMAIL_HOST_PASSWORD 是否为最新的‘授权码’。")
        elif "Connection unexpectedly closed" in str(e):
            print("  原因：连接被服务器强制关闭。可能是端口协议（SSL/TLS）不匹配，建议切换至 465 或 587 再次测试。")

if __name__ == '__main__':
    test_send()
