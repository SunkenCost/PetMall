import os
import django
# 图片测试脚本1
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from commodity.models import Product

def fix_images():
    products = Product.objects.all()
    count = 0
    colors = ['ff6b6b', '409eff', '67c23a', 'e6a23c', '909399']
    for p in products:
        c = colors[p.id % len(colors)]
        # 使用国内比较稳定的无版权占位图生成服务 (带字和随机颜色背景)
        p.main_image = f"https://dummyimage.com/600x600/{c}/ffffff&text=Pet+Goods+{p.id}"
        p.save()
        count += 1
    print(f"成功将 {count} 个商品的失效首图更换为带色彩的占位图。")

if __name__ == '__main__':
    fix_images()
