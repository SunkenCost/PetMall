import os
import django

# 设置环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from accounts.models import User

def reset_pwd():
    username = 'test1'
    password = '123456'
    u = User.objects.filter(username=username).first()
    if u:
        u.set_password(password) # 重新加密并设置密码
        u.is_staff = True        # 再次确认商家权限
        u.is_active = True       # 确保账号没被禁用
        u.save()
        print(f"Password for '{username}' has been RESET to '{password}'")
        print(f"Merchant status: {u.is_staff}")
    else:
        # 如果 test1 居然不存在，我就直接新建一个
        User.objects.create_user(username=username, password=password, is_staff=True)
        print(f"User '{username}' did not exist, so I CREATED it with password '{password}' and Staff=True")

if __name__ == "__main__":
    reset_pwd()
