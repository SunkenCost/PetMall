import os
import django
import random
import uuid
from datetime import datetime, timedelta
from decimal import Decimal

# 设置 Django 环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from django.contrib.auth import get_user_model
from shopper.models import OrderInfo, OrderItem, Address
from commodity.models import Product

User = get_user_model()

def create_mock_orders(count=20):
    users = list(User.objects.filter(is_superuser=False))
    products = list(Product.objects.all())
    
    if not users:
        print("错误: 没有普通用户，请先注册几个用户。")
        return
    if not products:
        print("错误: 没有商品数据，请先添加商品。")
        return

    statuses = ['PENDING', 'PAID', 'SHIPPED', 'COMPLETED']
    payment_methods = ['ALIPAY', 'WECHAT', 'CREDIT_CARD']

    print(f"正在插入 {count} 条模拟订单数据...")

    for i in range(count):
        user = random.choice(users)
        # 获取用户地址，如果没有则创建一个
        address = Address.objects.filter(user=user).first()
        if not address:
            address = Address.objects.create(
                user=user,
                receiver_name=f"{user.username}的收件人",
                receiver_phone="13800138000",
                province="上海市",
                city="上海市",
                district="浦东新区",
                detail_address="模拟测试路 888 号",
                is_default=True
            )

        status = random.choice(statuses)
        order_no = datetime.now().strftime('%Y%m%d%H%M%S') + str(random.randint(1000, 9999))
        
        # 随机下单时间（过去30天内）
        days_ago = random.randint(0, 30)
        created_at = datetime.now() - timedelta(days=days_ago)

        order = OrderInfo.objects.create(
            order_no=order_no,
            user=user,
            receiver_name=address.receiver_name,
            receiver_phone=address.receiver_phone,
            receiver_address=f"{address.province}{address.city}{address.district}{address.detail_address}",
            status=status,
            payment_method=random.choice(payment_methods) if status != 'PENDING' else None,
            payment_time=created_at + timedelta(minutes=random.randint(5, 60)) if status != 'PENDING' else None,
            create_time=created_at
        )

        # 随机 1-3 个商品
        num_items = random.randint(1, 3)
        order_products = random.sample(products, num_items)
        total_amount = Decimal('0.00')

        for prod in order_products:
            qty = random.randint(1, 2)
            subtotal = prod.price * qty
            OrderItem.objects.create(
                order=order,
                product=prod,
                product_name=prod.name,
                product_price=prod.price,
                quantity=qty,
                subtotal=subtotal
            )
            total_amount += subtotal
        
        order.total_amount = total_amount
        order.save()
        
        # 修正创建时间（因为 auto_now_add=True 会覆盖手动设置，这里通过 update 强制修改）
        OrderInfo.objects.filter(id=order.id).update(create_time=created_at)

    print(f"成功插入 {count} 条订单数据！")

if __name__ == '__main__':
    create_mock_orders(30)
