import os
import django
# 添加测试用户脚本
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from accounts.models import User, SysRole

def create_accounts():
    # 确保基础买家角色存在
    user_role, _ = SysRole.objects.get_or_create(role_code='USER', defaults={'role_name': '普通买家'})
    
    test_data = [
        ('123456', '123456', '测试大佬'),
        ('888888', '888888', '尊贵体验官'),
        ('test1', '123456', '一号铲屎官'),
        ('admin1', '123456', '演示小助手')
    ]
    
    count = 0
    for username, password, real_name in test_data:
        if not User.objects.filter(username=username).exists():
            User.objects.create_user(
                username=username,
                password=password,
                real_name=real_name,
                email=f"{username}@test.com",
                role=user_role
            )
            count += 1
            print(f"✅ 创建成功 => 账号: {username}  密码: {password} ({real_name})")
        else:
            print(f"⚠️ 账号已存在 => {username}")
            
    print(f"\n🎉 批量测试账号生成完毕，共新增了 {count} 个账号！")

if __name__ == '__main__':
    create_accounts()
