import os
import sys
import django
import random
from datetime import date, timedelta

# 获取项目根目录（假设脚本在 test/backend_scripts/ 下）
# 获取 x:\pet\shopping\backend\server 路径
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BACKEND_DIR = os.path.join(BASE_DIR, 'backend', 'server')

# 将 backend/server 添加到 sys.path
sys.path.append(BACKEND_DIR)

# 设置 Django 环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()

from accounts.models import User, SysRole
from shopper.models import PetProfile, Address, OrderInfo, OrderItem
from commodity.models import Category, Product, Inventory

def create_test_data():
    print("开始从 test 目录执行测试数据插入脚本...")

    # 1. 确保存在角色（可选，根据系统逻辑决定是否必须）
    customer_role, _ = SysRole.objects.get_or_create(
        role_code='CUSTOMER',
        defaults={'role_name': '普通会员', 'description': '普通商城消费用户'}
    )

    # 2. 创建测试分类和商品
    cat, _ = Category.objects.get_or_create(
        name='测试商品分类', 
        defaults={'level': 1, 'sort_order': 1, 'status': True}
    )
    
    product_data = [
        ('全价无谷猫粮 5kg', 199.00),
        ('冻干鸡肉粒 500g', 88.00),
        ('智能全自动猫砂盆', 1299.00),
        ('天然豆腐猫砂 6L', 25.00),
        ('三文鱼罐头 85g*6', 45.00),
    ]
    
    test_products = []
    for name, price in product_data:
        p, created = Product.objects.get_or_create(
            name=name,
            defaults={
                'category': cat,
                'price': price,
                'old_price': price * 1.2,
                'description': f'这是 {name} 的测试描述，旨在测试订单和档案功能。',
                'status': True
            }
        )
        test_products.append(p)
        # 确保有库存
        Inventory.objects.get_or_create(
            product=p, 
            defaults={'current_quantity': 200, 'warning_threshold': 10}
        )
    
    print(f"商品数据准备就绪，共 {len(test_products)} 个商品。")

    # 3. 创建测试客户
    names = ['钱九', '林十', '张十一']
    for i, name in enumerate(names):
        username = f'test_user_{i+7}' # 接着上一步的编号
        user, created = User.objects.get_or_create(
            username=username,
            defaults={
                'real_name': name,
                'phone': f'139{i:08d}',
                'role': customer_role,
            }
        )
        if created:
            user.set_password('123456')
            user.save()
            print(f"创建新用户: {username} (密码: 123456)")
        else:
            print(f"用户已存在: {username}")

        # 4. 为每个用户创建宠物档案
        pets = [
            (f"{name}的布偶", "猫", "布偶猫"),
            (f"{name}的柯基", "狗", "柯基")
        ]
        # 每个用户随机 1-2 个宠物
        for p_name, p_type, breed in random.sample(pets, random.randint(1, 2)):
            pet, p_created = PetProfile.objects.get_or_create(
                user=user,
                pet_name=p_name,
                defaults={
                    'pet_type': p_type,
                    'breed': breed,
                    'gender': random.randint(1, 2),
                    'size': random.choice(['SMALL', 'MEDIUM', 'LARGE']),
                    'birthday': date.today() - timedelta(days=random.randint(300, 1500))
                }
            )
            if p_created:
                print(f"  - 为 {username} 创建宠物: {p_name}")

        # 5. 创建收货地址
        addr, a_created = Address.objects.get_or_create(
            user=user,
            receiver_name=name,
            defaults={
                'receiver_phone': user.phone or '13999999999',
                'province': '上海市',
                'city': '上海市',
                'district': '浦东新区',
                'detail_address': f'测试路{i+10}号',
                'is_default': True
            }
        )

        # 6. 为用户创建一些订单
        for o_idx in range(random.randint(1, 2)):
            order_no = f'ORD{date.today().strftime("%Y%m%d")}{user.id}{random.randint(1000, 9999)}'
            
            # 随机选择 1-3 个商品
            order_products = random.sample(test_products, random.randint(1, 3))
            
            order = OrderInfo.objects.create(
                order_no=order_no,
                user=user,
                receiver_name=addr.receiver_name,
                receiver_phone=addr.receiver_phone,
                receiver_address=f"{addr.province}{addr.city}{addr.district}{addr.detail_address}",
                status=random.choice(['PENDING', 'PAID', 'SHIPPED', 'COMPLETED']),
                total_amount=0 # 稍后计算
            )
            
            total = 0
            for prod in order_products:
                qty = random.randint(1, 2)
                subtotal = prod.price * qty
                OrderItem.objects.create(
                    order=order,
                    product=prod,
                    product_name=prod.name,
                    product_price=prod.price,
                    quantity=qty,
                    subtotal=subtotal
                )
                total += subtotal
            
            order.total_amount = total
            order.save()
            print(f"  - 为 {username} 创建订单: {order_no}, 金额: {total}")

    print("\n所有测试数据插入完成！")

if __name__ == '__main__':
    create_test_data()
