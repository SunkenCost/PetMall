# PetMall 阿里云 ECS (Ubuntu 22.04) 部署全攻略

本教程专为你的阿里云服务器 (IP: **114.215.167.184**, 2核2G内存) 定制。旨在解决镜像缓存、数据库初始化失败以及前端 404/502 等历史遗留故障。

---

## 阶段一：本地准备 (本地电脑操作)

在上传代码之前，必须在本地完成以下“精装修”，防止将脏数据或错误配置带上服务器。

### 1. 修改后端生产配置
确保 `backend/server/server/settings.py` 中：
- `ALLOWED_HOSTS` 包含 `114.215.167.184`。
- `DEBUG` 设置为从环境变量读取（我们已在代码中完成此修改）。

### 2. 前端本地预构建 (关键！)
不要在服务器上进行安装和构建，那会极度消耗内存导致死机。
1. 在本地进入 `frontend/web` 目录。
2. 运行 `npm install`。
3. 运行 `npm run build`。
4. **验证**：确保生成了 `dist` 文件夹，且里面有 `index.html`。

### 3. 下载并校验商品图
确保你本地运行过搜图脚本，且 `backend/server/media/imgs/` 下有 pd_1.jpg 到 pd_30.jpg。

### 4. 代码打包
将整个项目目录打包为 `shopping.zip`。
> [!TIP]
> 打包时可以排除 `node_modules` 和 `.venv` 文件夹以减小体积（Docker 会在服务器上自动重装后端依赖，前端我们直接用构建好的 dist）。

---

## 阶段二：服务器环境搭建 (阿里云 ECS 操作)

### 1. 安全组开放端口
登录阿里云后台，在安全组规则中确保以下入方向端口已打开：
- `80`, `443`, `22`, `3306`

### 2. 安装 Docker 与 Docker Compose
如果服务器还没装，请执行：
```bash
# 获取安装脚本并执行
curl -fsSL https://get.docker.com | bash -s docker --mirror Aliyun
# 启动 Docker
systemctl start docker
systemctl enable docker
# 验证版本
docker version
```

---

## 阶段三：正式部署与“降维打击” (上线执行)

### 1. 上传并清理
将 `shopping.zip` 上传到服务器 `/opt/projects/` 并解压。
进入项目根目录：
```bash
# 进入目录
cd /opt/projects/shopping

# 【重点】内存清理：2G 内存服务器如果构建失败，请先运行这行清理旧镜像
docker system prune -a -f
```

### 2. 一键拉起服务
```bash
# 使用强制重新构建模式，杜绝缓存幽灵
docker-compose up -d --build --force-recreate
```

### 3. 数据库初始化 (必须按顺序执行)
容器起来后，执行以下命令完成数据灌入：

```bash
# 1. 创建数据库表结构
docker exec petmall_backend python manage.py migrate

# 2. 刷入所有核心测试数据 (含 30 个商品及其图片映射)
docker exec petmall_backend python test/backend_scripts/test_init_data.py

# 3. (可选) 创建超级管理员账号
docker exec petmall_backend python manage.py createsuperuser
```

---

## 阶段四：常见问题排查方案

### 1. 前端看到的是 404 或 Nginx 欢迎页？
- **检查**：确认服务器上的 `frontend/web/dist` 文件夹是否存在且非空。
- **原因**：通常是 COPY 路径不对，检查 `docker-compose.yml` 中的挂载路径。

### 2. 后端 API 报 502 Bad Gateway？
- **检查日志**：`docker-compose logs -f backend`。
- **原因**：通常是后端因为 `requirements.txt` 里的包没装全（如 `simpleui`）导致启动失败。

### 3. 图片还是原来的测试动物图？
- **检查**：进入容器查看文件 `docker exec -it petmall_backend ls /app/media/imgs/`。
- **原因**：确保本地下载的图确实被上传到了服务器的正确目录。

---

**恭喜！按照此流程操作，你的 PetMall 毕设项目将在 114.215.167.184 上完美运行。**
