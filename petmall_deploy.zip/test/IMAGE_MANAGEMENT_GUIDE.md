# PetMall 商品图管理与运维手册

本手册记录了 PetMall 项目在开发阶段遇到的图片管理问题、失败原因及最终的“标准恢复流程”。

## 1. 历史故障回顾 (2026-04-11)

### 现象
- 数据库中商品主图字段 (`main_image`) 为空或展示为失效的外部长链接（Unsplash 404）。
- 前台页面显示占位图或破碎图片图标。

### 失败原因 (Root Cause)
1. **反爬虫拦截**：自动搜图工具请求频率过高，触发了 DuckDuckGo 的 403 频率限制。
2. **初始化逻辑冲突**：多个测试脚本定义的商品范围不一致，导致“修了后面漏了前面”。
3. **静默下载失败**：脚本在下载 404 页面时未检测内容有效性，导致数据库里存了路径但物理文件损坏。

---

## 2. 标准添加/恢复流程 (动静分离方案)

项目采用**动静分离**设计。商品图属于“动态媒体资源”，其标准管理流程如下：

### 第一步：物理文件存放
所有商品图必须存放在：
- **物理路径**：`backend/server/media/imgs/`
- **命名规范**：`pd_{id}.jpg` (或描述性名称，如 `cat_food_main.jpg`)

### 第二步：数据库关联
在 Django 模型中，`main_image` 字段应存储**相对路径**（相对于 `MEDIA_ROOT`）：
- **正确格式**：`imgs/pd_1.jpg`
- **错误格式**：`https://...` (外部链接不稳定) 或 `/app/media/...` (硬编码绝对路径)

### 第三步：一键恢复脚本 (推荐)
如果需要批量重置或修复 30 个商品图，可执行以下命令：

```bash
# 在项目根目录下执行 (进入后端容器运行)
docker exec petmall_backend python -c "
import os, django, requests
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'server.settings')
django.setup()
from commodity.models import Product

# 定义 30 个商品的可靠素材库 (Unsplash CDN)
img_pool = { ... } # 脚本详情参考下文

# 执行循环下载与更新...
"
```

---

## 3. 运维注意事项

1. **缓存清理**：当你修改了本地物理文件但 URL 没变时，浏览器会优先读取缓存。请使用 `Ctrl + F5` 强制刷新。
2. **容器持久化**：由于我们使用了 `volumes` 挂载，你在容器内下载的图片会实时同步到宿主机的 `backend/server/media/imgs`，**删除容器不会导致图片丢失**。
3. **批量搜图**：建议使用经过验证的素材池，而不是实时抓取，以保证商城视觉风格统一。

---

## 4. 最终状态检查 (Checklist)
- [x] `backend/server/media/imgs` 包含 pd_1.jpg 至 pd_30.jpg。
- [x] Django 数据库中对应商品的 `main_image` 均以 `imgs/` 开头。
- [x] Nginx 转发规则中 `/media/` 映射到了正确的物理目录。
